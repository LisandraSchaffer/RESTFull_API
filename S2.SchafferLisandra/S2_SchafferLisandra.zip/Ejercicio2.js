
//2. Completa el siguiente código para que muestre "Acceso permitido" si la variable contraseña es igual a "secreta", y "Acceso denegado" en caso contrario, recuerda conteplar el tipo de dato de la contraseña.

let contraseña = "secreta";
if (contraseña === "secreta") {
    console.log("Acceso permitido");
} else {
    console.log("Acceso denegado");
}