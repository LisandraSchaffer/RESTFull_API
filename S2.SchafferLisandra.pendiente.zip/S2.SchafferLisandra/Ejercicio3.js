//3. Completa el siguiente código para que imprima por pantalla la cadena de texto a mostrarse en cada caso.
let numero = 99;
if (numero % 2 === 0) {
    console.log("El número es par");
} else {
    console.log("El número es impar");
}

